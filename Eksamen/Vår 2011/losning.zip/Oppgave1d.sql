﻿-- 1d

Select
  XMLElement("produkter",
    XMLAgg(
      XMLElement("produkt",
        XMLElement("pnr", pnr),
        XMLElement("type", ptype),
        XMLElement("navn", navn),
        XMLElement("adresse", adr),
        XMLElement("postnr", postnr),
        XMLElement("telefon", tlf)
      )
    )
  ) "XML"
From Produkt;

-- Resultatet kan bli omtrent slik:

/*

<produkter>
  <produkt>
    <pnr>2843</pnr>
    <type>Hotell</type>
    <navn>Bø Hotell</navn>
    <adresse>Gullbringvegen 32</adresse>
    <postnr>3800</postnr>
    <telefon>35950111</telefon>
  </produkt>
  <produkt>
    <pnr>4558</pnr>
    <type>Hotell</type>
    <navn>Vinje Turisthotell</navn>
    <adresse>Åmot</adresse>
    <postnr>3890</postnr>
    <telefon>35071300</telefon>
  </produkt>
  <produkt>
    <pnr>2854</pnr>
    <type>Museum</type>
    <navn>Heddal bygdemuseum</navn>
    <adresse>Bekkhusvegen 21</adresse>
    <postnr>3670</postnr>
    <telefon>35020840</telefon>
  </produkt>
</produkter>

*/
﻿// 1f

/*
Løsningsforslaget innfører et antall hjelpefunksjoner.
Noen vil kanskje plassere disse på en egen fil og
importere med include. Andre vil kanskje ikke bruke
hjelpefunksjoner i det hele tatt. Synes alle varianter
bør kunne gi full uttelling.

Varianter av de generelle hjelpefunksjonene db_connect,
db_do_query, db_close mfl. er brukt i undervisningen,
men er ikke en del av noe standardbibliotek.

Det viktigste er at logikken er på plass:
- Hent HTML skjemadata
- Bygg opp SQL-spørring
- Kjør SQL-spørring med oci8-funksjoner
- Gjennomløp av spørreresultat med løkke
  og produksjon av HTML-respons
*/

<?php
// Hjelpefunksjon for å koble opp databasen
function db_connect() {
  $bruker = 'brukernavn';
  $passord = 'passord';
  $dburl = 'bo197154.hit.no/ifim2';
  $tegnsett = 'AL32UTF8';
  
  -- Et kall på oci_connect bør være med!
  $conn=oci_connect($bruker, $passord, $dburl, $tegnsett);
  if (!$conn)
    exit('<p><b>Klarte ikke å koble opp til databasen!</b></p>');
  return $conn;
}

// Hjelpefunksjon for å utføre SQL-spørring
function db_do_query($conn, $statement) {
  -- Et kall på oci_parse bør være med!
  $stid = oci_parse($conn, $statement);
  if (!$stid)
    exit('<p><b>Tolking av SQL-spørring feilet!</b></p>');
  
  -- Et kall på oci_execute bør være med!
  $r = oci_execute($stid);
  if (!$r)
    exit('<p><b>Utførelse av SQL-spørring feilet!</b></p>');
  
  -- Bruk av en oci_fetch_* bør være med, enten alle i en jafs,
  -- eller ei løkke og oci_fetch_row...
  $numRows = oci_fetch_all($stid, $results, 0, -1, OCI_FETCHSTATEMENT_BY_ROW+OCI_ASSOC);
  return $results;
}

// Hjelpefunksjon for å lukke forbindelse til databasen
function db_close($conn) {
  -- Fint hvis oci_close er med!
  oci_close($conn);
}

// Hjelpefunksjon for å hente museer på gitt postnr
function hent_museer($conn, $postnr) {
  -- En SQL-spørring må være med
  $stmt = "SELECT * FROM Produkt WHERE postnr=$postnr";
  return db_do_query($conn, $stmt);
}

// Hjelpefunksjon for å presentere museer på gitt postnr
function vis_museer($museer) {
  -- Ei løkke for presentasjon som HTML-liste bør være med
  print('<ul>');
  foreach ($museer as $museum) {
    print('<li>' . $museum['NAVN'] . '</li>');
  }
  print('</ul>');
}
?>

<html>
<body>
<h1>Museer</h1>

<?php
$postnr = $_REQUEST['txtPostNr']; -- Tåler både GET og POST
$conn = db_connect();
$museer = hent_museer($conn, $postnr);
vis_museer($museer);
db_close($conn);
?>

</body>
</html>

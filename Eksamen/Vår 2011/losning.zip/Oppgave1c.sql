﻿-- 1c

Create Or Replace Function TotalPris
(
  p_rnr     In  Reise.rnr%TYPE,
  p_mnd     In  Pris.mnd%TYPE
)
  Return Number
Is
  v_pris Number;
Begin
  Select  SUM(PR.pris * PIR.antall) Totalt
  Into    v_pris
  From    ProduktIReise PIR, Produkt P, Pris PR
  Where   PIR.pnr = P.pnr
  And     P.pnr = PR.pnr
  And     PIR.rnr = p_rnr
  And     PR.mnd = p_mnd;
  
  Return v_pris;
Exception
  When NO_DATA_FOUND Then
    Return -1;
End;
/

-- Tester funksjonen

-- Pris for reise 3649 i juli (måned 7)
Select TotalPris(3649, 7) From DUAL;

﻿-- 1a

Create Sequence produkt_seq;

Create Or Replace Trigger produkt_insert_tr
  Before Insert On Produkt
  For Each Row
Declare
  v_pnr Produkt.pnr%Type;
Begin
  Select  produkt_seq.Nextval
  Into    v_pnr
  From    dual;
  
  :New.pnr := v_pnr;
End;
/

Create Or Replace Procedure NyttHotell
(
  p_navn      In  Produkt.navn%TYPE,
  p_adr       In  Produkt.adr%TYPE,
  p_postnr    In  Produkt.postnr%TYPE,
  p_tlf       In  Produkt.tlf%TYPE
)
Is
Begin
  Insert Into Produkt(ptype, navn, adr, postnr, tlf)
  Values('Hotell', p_navn, p_adr, p_postnr, p_tlf);
  
  Commit;
End;
/


-- Test (ikke en del av oppgaven):

Exec NyttHotell('Park Hotell', 'Kongens gate 1', '3800', '12345678');
Select * From Produkt;

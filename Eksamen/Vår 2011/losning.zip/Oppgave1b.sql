﻿-- 1b

Create Or Replace Procedure VisReiser
Is
  Cursor c_reiser Is
    Select    *
    From      Reise;
  Cursor c_produkt(p_rnr Reise.rnr%Type) Is
    Select    P.pnr, P.navn
    From      ProduktIReise PIR, Produkt P
    Where     PIR.pnr = P.pnr
    And       PIR.rnr = p_rnr;
Begin
  For v_reise In c_reiser Loop
    dbms_output.put_line(v_reise.rnr || ' ' ||
      v_reise.rnavn);
    For v_produkt In c_produkt(v_reise.rnr) Loop
      dbms_output.put_line('-' || v_produkt.pnr ||
        ' ' || v_produkt.navn);
    End Loop;
  End Loop;
End;
/

-- Test (ikke en del av oppgaven)

Exec VisReiser;

<?php 

session_destroy();
header("location: oppgave1a.html");

?>
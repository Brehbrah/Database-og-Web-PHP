<?php 

function toppHTML() {
	echo '<!doctype html>
	<html>
		<head>
			<meta charset="utf-8">
			<meta name="description" content="">
			<meta name="viewport" content="width=device-width, initial-scale=1">
			<title>Databaser og web || Vår 2016 Eksamen</title>
			<link rel="stylesheet" href="css/style.css">
			<link rel="author" href="humans.txt">
			<script src="script.js"></script>
		</head>
	<body>';
}

function bunnHTML() {
		echo '</body>
	</html>';
}

?>
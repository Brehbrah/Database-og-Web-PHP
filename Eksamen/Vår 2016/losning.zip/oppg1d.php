<?php
include_once "hjelpere.php";

$db = kobleOpp();

// Henter alle kategoriene fra databasen...
$sql = "SELECT * FROM Kategori";
$resultat = mysqli_query($db, $sql);
$rad = mysqli_fetch_assoc($resultat);

?>

<!DOCTYPE html>
<html>

<head>
  <title>Databaser og web</title>
  <meta charset="UTF-8" />
  <script src="oppg1a.js" defer></script>
</head>

<body>

<h1>Oppgave 1a: Registrere utleieobjekt</h1>

<form id="regskjema" action="oppg1b.php" method="POST">

  <p>
    <label>Beskrivelse:</label>
    <input type="text" name="beskrivelse" id="beskrivelse" required>
  </p>
  
  <p>
    <label>Kategori:</label>
    <select name="katnr" id="katnr">

      <?php
      // ... og genererer nedtrekkslisten.
      while ($rad) {
        $katnr = $rad['KatNr'];
        $navn = $rad['Navn'];
        echo "<option value=\"$katnr\">$navn</option>";
        $rad = mysqli_fetch_assoc($resultat);
      }
      ?>

    </select>
  </p>

  <p>
    <label>Dagpris:</label>
    <input type="text" name="dagpris" id="dagpris" required>
  </p>

  <p>
    <input id="submit" type="submit" value="Registrer objekt!" required>
  </p>
  
  <div id="melding"></div>
  
</form>

</body>

</html>

<?php
  lukk($db);
?>

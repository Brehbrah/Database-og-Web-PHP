-- Fordi ; brukes som skilletegn mellom setninger i CREATE PROCEDURE
DELIMITER $$

DROP PROCEDURE IF EXISTS nytt_leieforhold $$

CREATE PROCEDURE nytt_leieforhold
(
	IN  p_epost      CHAR(100),
	IN  p_fradato    DATE,
  IN  p_tildato    DATE,
  IN  p_poengsum   INTEGER,
  OUT p_melding    VARCHAR(50)
)
BEGIN
  DECLARE v_antall INT;
  
  SET p_melding = '';
  
  SELECT COUNT(*) INTO v_antall
  FROM Bruker
  WHERE epost = p_epost;
  
  IF v_antall = 0 THEN
    SET p_melding = 'Leieren finnes ikke!';
  ELSE
    IF p_tildato < p_fradato THEN
      SET p_melding = 'Fra-dato må være før til-dato!'; 
    ELSE
      SET p_melding = 'Leieforholdet er lagret.';
  	  INSERT INTO Leieforhold(LeierEpost, FraDato, TilDato, Poengsum)
      VALUES (p_epost, p_fradato, p_tildato, p_poengsum);
    END IF;
  END IF;
END $$

DELIMITER ;


-- Test (ba ikke om det)

CALL nytt_leieforhold('jonny@li.no', '2016-11-11', '2016-11-16', 7, @melding);

-- Kan ha SELECT uten FROM i MySQL
SELECT @melding;

CALL nytt_leieforhold('ukjent@xyz.no', '2016-11-11', '2016-11-16', 7, @melding);

SELECT @melding;

CALL nytt_leieforhold('jonny@li.no', '2016-11-18', '2016-11-17', 8, @melding);

SELECT @melding;

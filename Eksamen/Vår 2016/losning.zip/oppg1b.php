<?php
session_start();

// Antagelse i oppgaveteksten hardkodes
$_SESSION['BrukerEpost'] = 'ola@outlook.com';

include_once "hjelpere.php";

topp();
$db = kobleOpp();

echo "<h1>Oppgave 1b</h1>";

$epost = $_SESSION['BrukerEpost'];

// Avleser skjemadata
$beskrivelse = $_POST['beskrivelse'];
$katnr = $_POST['katnr'];
$dagpris = $_POST['dagpris'];

// Sjekker at kategorien finnes.
// Bruker prepared statements for å hindre SQL injection.
$sql = "SELECT * FROM Kategori WHERE KatNr=?";
$stmt = mysqli_prepare($db, $sql);
mysqli_stmt_bind_param($stmt, "i", $katnr);
mysqli_stmt_execute($stmt);
$resultat = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($resultat)==1) { // Kategorien finnes

  // Primærnøkkelen er autogenerert og hoppes over
  $sql = "INSERT INTO UtleieObjekt(Beskrivelse, EierEpost, KatNr, DagPris) "
       . "VALUES(?, ?, ?, ?)";
  $stmt = mysqli_prepare($db, $sql);

  // Plugger inn parametre - en string - en string - en integer og en desimal
  mysqli_stmt_bind_param($stmt, "ssid", $beskrivelse, $epost, $katnr, $dagpris);

  if (mysqli_stmt_execute($stmt)) {
    $objnr= mysqli_insert_id($db); // Henter siste løpenummer
    echo "<p>Utleieobjekt $objnr ble lagret korrekt.</p>";
  }
  else {
    $mld = mysqli_error($db);
    echo "<p>Noe gikk galt: $mld</p>";
  }
}
else {
  echo "<p>Kategorien finnes ikke!</p>";
}

lukk($db);
bunn();

?>

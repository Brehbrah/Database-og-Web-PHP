function sjekkSkjema() {
  var beskrivelse = document.getElementById('beskrivelse').value;
  var katnr = document.getElementById('katnr').value;
	var dagpris = document.getElementById('dagpris').value;

  var feilmld = "";
  
  // Sjekk på at et felt er fylt ut kan gjøres som følger,
  // eller ved å sette feltet som required i HTML-skjemaet.
  if (beskrivelse == "" || katnr == "" || dagpris == "") {
    feilmld += "<p>Alle felt må fylles ut!</p>";
  }

  if (dagpris < 20 || dagpris > 2000) {
    feilmld += "<p>Lovlig dagpris er mellom 20 og 2000.</p>";
  }

  if (feilmld != "") {
    var melding = document.getElementById('melding');
	  melding.innerHTML = feilmld;
	  return false;
  }
  else {  
    return true;
  }
}

document.getElementById('regskjema').addEventListener("submit", function (e) {
  if (!sjekkSkjema()) {
    e.preventDefault();
  }
});

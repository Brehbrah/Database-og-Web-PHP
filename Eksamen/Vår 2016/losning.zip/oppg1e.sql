DELIMITER $$

DROP TRIGGER IF EXISTS trg_poengsum $$

CREATE TRIGGER trg_poengsum
  AFTER UPDATE ON Leieforhold
  FOR EACH ROW
BEGIN
  DECLARE v_poengsum INTEGER;

  SELECT ROUND(AVG(PoengSum), 0) INTO v_poengsum
  FROM Leieforhold
  WHERE LeierEpost = NEW.LeierEpost;

  UPDATE Bruker
  SET Poengsum = v_poengsum
  WHERE Epost = NEW.LeierEpost;
END $$

DELIMITER ;



-- Test (ba ikke om det)

UPDATE Leieforhold
SET Poengsum = 2
WHERE LNr = 1;

SELECT *
FROM Bruker;


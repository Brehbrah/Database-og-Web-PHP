<?php
include_once "hjelpere.php";

topp();
$db = kobleOpp();

echo "<h1>Oppgave 1c</h1>";

if (isset($_GET['epost'])) {

  $epost = $_GET['epost'];

  // Hopper over prepared statements og kontroll med
  // SQL injection her - se oppgave 1b.

  $sql = "SELECT L.LNr, U.Beskrivelse, K.Navn, 
      CONCAT(B.Fornavn, ' ', B.Etternavn) AS Leier,
      DATEDIFF(L.TilDato, L.FraDato) AS AntDager,
      L.Poengsum
    FROM Bruker AS B, Kategori AS K,
      Leieforhold AS L, UtleieObjekt AS U
    WHERE L.LeierEpost = B.Epost
    AND L.ObjNr = U.ObjNr
    AND U.KatNr = K.KatNr
    AND U.EierEpost = '$epost'";

  $resultat = mysqli_query($db, $sql);
  $rad = mysqli_fetch_assoc($resultat);

  echo "<ul>";
  while ($rad) {
    $beskrivelse = $rad['Beskrivelse'];
    $navn = $rad['Navn'];
    $leier = $rad['Leier'];
    $antDager = $rad['AntDager'];
    $poengsum = $rad['Poengsum'];

    // Minimal og litt kryptisk utskrift:
    echo "<li>$beskrivelse $navn $leier $antDager <b>$poengsum</b></p>";
    $rad = mysqli_fetch_assoc($resultat);
  }
  echo "</ul>";
}
else {
  echo '<p>Epost ikke oppgitt.</p>';
}

lukk($db);
bunn();

?>

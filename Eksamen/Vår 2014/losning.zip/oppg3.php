<?php
define("TJENER",  "localhost");
define("BRUKER",  "root");
define("PASSORD", ""); 
define("DB",      "eksamen");

$db = mysqli_connect(TJENER, BRUKER, PASSORD, DB);
if (!$db) {
  die('Database connection error: ' . mysql_error($db));
}
mysqli_set_charset($db, 'utf8');

$sok = $_GET['sok'];

$svar = array();

$sql = "SELECT qtext FROM question WHERE qtext LIKE '%$sok%'";
$result = mysqli_query($db, $sql);

$alt = mysqli_fetch_assoc($result);
while ($alt) {
  $svar[] = $alt["qtext"];
  $alt = mysqli_fetch_assoc($result);
}
mysqli_close($db);

echo json_encode($svar); // XML er også helt ok

?>
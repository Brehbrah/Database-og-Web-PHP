DELIMITER $$

DROP TRIGGER IF EXISTS trg_sporsmalstegn $$

CREATE TRIGGER trg_sporsmalstegn
  BEFORE INSERT ON question
  FOR EACH ROW
BEGIN
  SET NEW.qtext = CONCAT(NEW.qtext, '?');
END $$


-- Test

INSERT INTO question(tid, qid, qtext)
VALUES (1, 9, 'bla bla') $$

SELECT * FROM question $$

DELIMITER ;

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8" />
<script type="text/javascript">
function hentSvar(str) {
  var xmlhttp;
  
  if (window.XMLHttpRequest) {
    xmlhttp=new XMLHttpRequest();
  }
  else {
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
	  arr = eval(xmlhttp.responseText);
	  svar = "<ul>";
	  for (i=0; i<arr.length; i++)
	    svar += "<li>" + arr[i] + "</li>";
	  svar += "</ul>";
      document.getElementById("svar").innerHTML=svar;
    }
  }
  
  xmlhttp.open("GET", "oppg3.php?sok="+str, true);
  xmlhttp.send();
}
</script>
</head>
<body>

<h3>Responsside oppgave 3</h3>

<form action=""> 
  <p>
    Mønster: <input type="text" id="txtSok" />
    <button type="button" onclick="hentSvar(txtSok.value)">Hent spørsmål!</button>
  </p>
</form>

<p>Respons:</p>
<div id="svar"></div>

</body>
</html> 
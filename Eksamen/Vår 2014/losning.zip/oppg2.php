<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8" />
</head>
<body>

<?php
define("TJENER",  "localhost");
define("BRUKER",  "root");
define("PASSORD", ""); 
define("DB",      "eksamen");

$db = mysqli_connect(TJENER, BRUKER, PASSORD, DB);
if (!$db) {
  die('Database connection error: ' . mysql_error($db));
}
mysqli_set_charset($db, 'utf8');

$tid = $_GET['tid'];

echo "<h1>Resultat av test $tid</h1>\n";

$sql = "SELECT * FROM alternative WHERE tid = '$tid' AND correct = 1";
$result = mysqli_query($db, $sql);

$data = array();
$alt = mysqli_fetch_assoc($result);
while ($alt) {
  $qid = $alt["qid"];
  $aid = $alt["aid"];
  $data[$qid] = $aid;
  $alt = mysqli_fetch_assoc($result);
}
mysqli_close($db);

$correct = 0;
$error = 0;
$empty = count($data) - count($_POST);

foreach ($_POST as $key => $value) {
  $q = substr($key, 1);
  if ($value == $data[$q])
    $correct++;
  else
    $error++;
}

echo "<p>Antall korrekte: $correct.</p>";
echo "<p>Antall gale: $error.</p>";
echo "<p>Antall ubesvart: $empty.</p>";

?>

</body>
</html>

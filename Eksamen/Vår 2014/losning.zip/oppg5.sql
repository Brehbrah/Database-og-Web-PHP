DELIMITER $$

DROP FUNCTION IF EXISTS riktig_svar $$
 
CREATE FUNCTION riktig_svar
(
  p_tid INTEGER,
  p_qid INTEGER
)
  RETURNS CHAR(1)
  READS SQL DATA
BEGIN
  DECLARE v_aid CHAR(1);
  
  SELECT aid INTO v_aid
  FROM alternative
  WHERE tid = p_tid
  AND qid = p_qid
  AND correct = 1;
  
  RETURN v_aid;
END $$

-- Test
 
SELECT *, riktig_svar(tid, qid) AS korrekt
FROM question $$

DELIMITER ;

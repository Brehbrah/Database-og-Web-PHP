<?php

// Dummy-kode som viser dagens dato, klokkeslett og en standardmelding.
$naa = date('d.m.Y H:i:s');
echo "<p>$naa - Ikke implementert ennå!</p>";

?>